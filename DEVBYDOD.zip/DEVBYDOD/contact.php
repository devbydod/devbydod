<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $con = mysqli_connect('localhost', 'root', '', 'do_contact');

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $txtFirstName = $_POST['first_name'];
    $txtOtherName = $_POST['other_name'];
    $txtSurname = $_POST['surname'];
    $txtPhone = $_POST['phone'];
    $txtEmail = $_POST['email'];
    $txtmessage = $_POST['your_message'];

    $sql = "INSERT INTO dod_contact (Firstname, Othername, Surname, Phonenumber, Email, Your message)
            VALUES ('$txtFirstName', '$txtOtherName', '$txtSurname', '$txtPhone', '$txtEmail', '$txtmessage')";

    if (mysqli_query($con, $sql)) {
        echo "Contact Records have successfully been inserted.";
    } else {
        echo "Error: " . mysqli_error($con);
    }

    mysqli_close($con);
}
?>